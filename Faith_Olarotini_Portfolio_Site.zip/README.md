# Faith Olarotini | Virtual Assistant & Project Manager Portfolio

This is a personal portfolio website for Faith Olarotini, showcasing Virtual Executive Assistant and Project Management services.

## Live Demo

Once uploaded to GitHub and GitHub Pages is enabled, your portfolio will be live at:

```
https://yourusername.github.io/faith-portfolio/
```

## How to Use

1. Rename `Faith_Olarotini_Portfolio_Website.html` to `index.html`
2. Upload it to your GitHub repository.
3. Enable GitHub Pages from the Settings > Pages section.

## Contact Info

- Email: tomifaith001@gmail.com
- LinkedIn: [linkedin.com/in/faith-olarotimi](http://linkedin.com/in/faith-olarotimi)
- Calendly: [Book a Call](https://calendly.com/tomifaith001)